# macska > 2024-05-05 7:40am
https://universe.roboflow.com/workspace-yhdbj/macska

Provided by a Roboflow user
License: CC BY 4.0

